package cpsc2150.MyQueue;

abstract class AbsQueue<T> implements IQueue<T> {
    /**
     *@return A string representation of the private variables
     *@pre Be prepared for a String and caste if needed
     *@post No fields will have their values changed
     */
    @Override
    public String toString() {
        String output = "";
        T popped;

        if(size() == 0) {
            output = "Queue is empty\n";
            return output;
        }

        for(int i = 0; i < size(); i++){
            popped = pop();
            output = output + popped;
            if(i < size())
                output = output + ",";
            output = output + " ";
            add(popped);
        }
        output = output + "\n";

        return output;
    }
}
