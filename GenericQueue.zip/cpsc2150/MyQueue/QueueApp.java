package cpsc2150.MyQueue;

import java.util.*;

//Zachary Broome, Henry McGee
public class QueueApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        IQueue<Integer> q;
        final int MAX_DEPTH = 100;

        while (true) {

            System.out.println("1. Array implementation or \n" +
                    "2. List implementation?");
            String response = input.nextLine();
            if (response.equals("1")) {
                q = new ArrayQueue<Integer>();
                break;
            }
            if (response.equals("2")) {
                q = new ListQueue<Integer>();
                break;
            }
        }
        String response = " ";
        do {
            System.out.println("Select an option:");
            System.out.println("1. Add to the Queue");
            System.out.println("2. Get next number from the Queue");
            System.out.println("3. Peek at the front of the Queue");
            System.out.println("4. Peek at the end of the Queue");
            System.out.println("5. Insert in the Queue");
            System.out.println("6. Get a position in the Queue");
            System.out.println("7. Remove from a position in the Queue");
            System.out.println("8. Quit");
            response = input.nextLine();

            switch (response) {
                case "1":
                    if (q.size() >= MAX_DEPTH){
                        System.out.println("Queue is full");
                        break;
                    }
                    System.out.println("What number to add to the Queue?");
                    String numberSelected = input.nextLine();
                    int addInteger = Integer.parseInt(numberSelected);
                    q.add(addInteger);
                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;

                case "2":
                    if (q.size() == 0) {
                        System.out.println("The Queue is empty\n");
                        break;
                    }
                    System.out.println("Next number is: " + q.pop());
                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;
                case "3":
                    if (q.size() == 0) {
                        System.out.println("The Queue is empty\n");
                        break;
                    }
                    System.out.println("Peek: " + q.peek() + "\n");
                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;
                case "4":
                    if (q.size() == 0) {
                        System.out.println("The Queue is empty\n");
                        break;
                    }
                    System.out.println("Peek at end: " + q.endOfQueue() + "\n");
                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;

                case "5":
                    if (q.size() >= MAX_DEPTH){
                        System.out.println("Queue is full");
                        break;
                    }
                    int numberToInsert = 0;
                    int positionOfNumber = 0;

                    System.out.println("What number to add to the Queue?");
                    String numberToInsertString = input.nextLine();

                    numberToInsert = Integer.parseInt(numberToInsertString);

                    while (true) {
                        System.out.println("What position to insert in?");
                        numberToInsertString = input.nextLine();
                        positionOfNumber = Integer.parseInt(numberToInsertString);

                        if ((positionOfNumber <= (q.size() + 1)) && (positionOfNumber >= 1)) {
                            break;
                        }
                        System.out.println("Not a valid position in the Queue!");
                    }
                    q.insert(numberToInsert, positionOfNumber);
                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;
                case "6":
                    if (q.size() == 0) {
                        System.out.println("The Queue is empty\n");
                        break;
                    }

                    while (true) {
                        System.out.println("What position to get in the Queue?");
                        String numberToGetString = input.nextLine();
                        positionOfNumber = Integer.parseInt(numberToGetString);
                        if ((positionOfNumber <= q.size()) && (positionOfNumber >= 1)) {
                            break;
                        }
                        System.out.println("Not a valid position in the Queue!");
                    }
                    System.out.println(q.get(positionOfNumber) + " is at position " + positionOfNumber + " in the queue");

                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;
                //check 9 or more
                case "7":
                    if (q.size() == 0) {
                        System.out.println("The Queue is empty\n");
                        break;
                    }
                    while (true) {
                        System.out.println("What position to remove from the Queue?");
                        String numberToRemoveString = input.nextLine();
                        positionOfNumber = Integer.parseInt(numberToRemoveString);
                        if ((positionOfNumber <= q.size()) && (positionOfNumber >= 1)) {
                            break;
                        }
                        System.out.println("Not a valid position in the Queue!");
                    }
                    System.out.println(q.remove(positionOfNumber) + " was at position " + positionOfNumber + " in the queue");
                    System.out.println("Queue is:");
                    System.out.println(q.toString());
                    break;
                case "8":
                    System.out.println("Ending\n");
                    break;
                default:
                    System.out.println("not a valid option!");
                    System.out.println("Queue is:");
                    System.out.println(q.toString());

            }
        }while (!response.equals("8"));
    }
}
