package cpsc2150.MyQueue;

/**
 * A queue containing integers.
 * A queue is a data structure where the first item added to the structure is the first item removed from the structure
 * This queue is bounded by MAX_DEPTH
 *
 * Initialization ensures: Queue is empty
 * Defines: items_in_queue = n
 * Constraints: n <= MAX_DEPTH
 */

public interface IQueue<T> {

    int MAX_DEPTH = 100;

    // Adds x to the end of the Queue

    /**
     *
     * @param x int to add to the end of the Queue
     * @pre x is a valid number that does not exceed 4 bytes
     * @post x is added to the end of the Queue
     */
    void add(T x);

    //removes and returns the Integer at the front of the queue

    /**
     * @return return the item in the Queue
     * @pre make sure you are anticipating an integer and caste if needed
     * @post the number of integers in the Queue will be returned as an Integer
     */
    T pop();

    //returns the number of Integers in the Queue

    /**
     * @return number of Integers in the Queue
     * @pre be prepared for an Integer to be returned and caste if needed
     * @post number of Integers in the Queue will be returned
     */
    int size();

    /**
     * @return Integer at the front of the Queue
     * @pre be prepared for an Integer to be returned and caste if needed
     * @post The Queue will contain the same values
     */
    default T peek() {
        T result = pop();
        T popped = (T) new Object();
        add(result);
        for(int i = 0; i < size()-1; i++) {
            popped = pop();
            add(popped);
        }

        return result;
    }

    /**
     *@return Integer at the end of the Queue
     *@pre be prepared for an Integer to be returned and caste if needed
     *@post The Queue will contain the same values
     */
    default T endOfQueue() {
        T popped = (T) new Object();

        for(int i = 0; i < size(); i++) {
            popped = pop();
            add(popped);
        }

        return popped;
    }

    /**
     *@pre provide a valid Integer and position to put it into the Queue
     *@post The Queue will contain the Integer and its given position alongside the previous Integers
     */
    default void insert(T x, int pos) {
        T popped = (T) new Object();

        if(pos == (size() + 1))
            add(x);
        else {
            for (int i = 0; i < size(); i++) {
                if (pos == (i + 1))
                    add(x);
                else {
                    popped = pop();
                    add(popped);
                }
            }
        }
    }

    /**
     *@return returns the Integer at the given position
     *@pre pos > 0 && pos <= depth of Queue
     *@post Integer at the given position is removed from the Queue
     */
    default T remove(int pos) {
        T result = (T) new Object();
        T popped = (T) new Object();

        for(int i = 0; i < size() + 1; i++) {
            if(pos == (i + 1))
                result = pop();
            else {
                popped = pop();
                add(popped);
            }
        }
        return result;
    }

    /**
     *@return the Integer at the given position
     *@pre position > 0 && position <= depth of the Queue
     *@post  Queue will remain the same
     */
    default T get(int pos) {
        T result = (T) new Object();
        T popped = (T) new Object();

        for(int i = 0; i < size(); i++) {
            if(pos == (i + 1)) {
                result = pop();
                add(result);
            }
            else {
                popped = pop();
                add(popped);
            }
        }
        return result;
    }
}


