package cpsc2150.MyQueue;
import java.util.*;

public class ListQueue<T> extends AbsQueue<T> {
    /**
     * @invariant depth <= MAX_DEPTH
     * Correspondence items_in_queue = myQ.size()
     */
    //this time store the queue in a list
    //myQ.get(0) is the front of the queue
    private List<T> myQ;
    //complete the class

    /**
     * @post a new list of integers is created 
     */
    public ListQueue(){
        myQ = new ArrayList<T>();
    }

    public void add(T x){
        myQ.add(x);
    }

    public T pop(){
        return myQ.remove(0);
    }

    public int size(){
       return myQ.size();
    }
}
