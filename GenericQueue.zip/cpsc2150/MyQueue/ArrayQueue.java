package cpsc2150.MyQueue;

public class ArrayQueue<T> extends AbsQueue<T> {
    /**
     * @invariant depth <= MAX_DEPTH
     * Correspondence items_in_queue = depth
     */
    // where the data is stored. myQ[0] is the front of the queue
    private T[] myQ;
    //tracks how many items in the queue
    // also used to find the end of the queue
    private int depth;

    /**
     * @post a new ArrayQueue object with depth and myQ Queue are created
     */
    public ArrayQueue(){
        myQ = (T[])new Object[MAX_DEPTH];
        depth = 0;
    }

    public void add(T x){
        myQ[depth] = x;
        depth++;
    }

    public T pop(){
        T pop = myQ[0];
        for(int i = 0; i < depth; i++){
            myQ[i] = myQ[i + 1];
        }
        depth--;
        return pop;
    }

    public int size(){
        return depth;
    }
}

